<footer>
    <span>Stressfree Pets&copy; </span>
    <span>Phone: 018479685</span>
    <span>Email: stressfreepets@gmail.com</span>
    <span class="span-images"><a href ="https://www.facebook.com/"><img src="../images/facebook.png"></a></span>
    <span class="span-images"><a href="https://www.instagram.com/"><img src="../images/insta.jpg"></a></span>
    <span class="span-images"><a href="https://twitter.com/?lang=en"><img src="../images/x.png"></a></span>

        </footer>
    </div>
    <!-- /container -->

    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
</body>
</html>
