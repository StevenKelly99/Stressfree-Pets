<?php require_once '../layout/header.php'; ?>
<h3> Please select which service do you want to book for</h3>

<h4>Booking for Dog DayCare
    <a href="dayCareBooking.php"><button type="button">Book here</button></a></h4>

<h4>Booking for In Home Sitting
    <a href="booking.php"><button type="button">Book here</button></a></h4>

<h4>Booking for Out Home Sitting
    <a href="OutHomeBooking.php"><button type="button">Book here</button></a></h4>

<h4>Booking for Dog Walking
    <a href="petWalkingBooking.php"><button type="button">Book here</button></a></h4>
<br>

<h4>If you want to go back to home page please <a href="index.php"> click here </h4>

<?php require_once '../layout/header.php'; ?>
