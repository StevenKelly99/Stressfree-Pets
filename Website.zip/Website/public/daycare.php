<?php require_once "../layout/header.php";?>
<h1 class="headingFaq">Dog daycare</h1>

<div class="text-center">

<div class="daycare">
    <div class="text-center">
        <img src="../images/daycare.jpg" height="300" width="550" alt="petWalkingImg"></div>
    <h3>Daycare is going to make your pet more socialised, play, do exercise.
        prevent loneliness and anxiety, watch your dog take care of it
        by specialised personnel</h3>
</div>
</div>
<h4>if you think this service is perfect for you can
    <a href="dayCareBooking.php"><button type="button">Book here</button></a></h4>

<div class="text-center">
    <h3>If you want to book for another service <a href="bookingType.php">Click here</a></h3>
    <h4>If you want to go back to home page <a href="index.php">Click here</a></h4>

</div>


<?php require_once "../layout/footer.php"; ?>
