<?php require_once"../layout/header.php"?>

<h1 class="headingFaq">Pet Walking</h1>
<div class="text-center">
    <div class="text-center">
        <img src="../images/petWalking.jpg" height="300" width="650" alt="petWalkingImg"></div><br>
    <h4>Pet Walking Service is providing help for your pets, such as taking your dog to the vet.
        helping your dog lose weight, keeping track of your dog's food,
        Keep an eye on your pet's health. Help your dog learn new things.
        Clean your dog's stuff and give your dog a bath.</h4>
</div>

    <h4>if you think this service is perfect for you can
        <a href="petWalkingBooking.php"><button type="button">Book here</button></a></h4>

<div class="text-center">
    <h3>If you want to book for another service <a href="bookingType.php">Click here</a></h3>
    <h4>If you want to go back to home page <a href="index.php">Click here</a></h4>


<?php require_once"../layout/footer.php" ?>



