<?php require_once '../layout/header.php'; ?>
<div class="text-center">
    <h2>CONTACT</h2></div>
<link rel="stylesheet" type="text/css" href="../css/style.css">

<div class="contact-info">
    <h4>Contact Information</h4>
    <p><img width="24" height="24" src="https://img.icons8.com/material-outlined/24/phone.png" alt="phone"/>+353 018 479 685</p>
    <p><img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/new-post.png" alt="new-post"/></i>stressfreepets@gmail.com</p>
    <p><img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/order-delivered.png" alt="order-delivered"/>Address: Blanchardstwon, Dublin, Ireland</p>


</div>
<?php require_once '../layout/footer.php'; ?>
