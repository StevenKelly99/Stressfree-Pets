<?php require_once '../layout/header.php'; ?>
 <h1>Your appointment has been cancelled. <a href="index.php">Click here</a> to go back to home page</h1>
<?php require_once '../layout/footer.php';?>
