
<?php require_once '../layout/header.php'; ?>

<?php

echo "Thank your for booking. You will receive a confirmation email soon";
?>
    <a href="index.php"> <br> Click here to return to home page</a>
<?php require_once'../layout/footer.php'; ?>