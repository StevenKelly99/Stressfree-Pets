<?php
	$total = 0;
	$pageTitle = 'Shopping Cart';
?>
<?php require_once '_header.php'; ?>

<div class="row no_product">
    (There are no items in your shopping cart)
</div>

</body>
</html>
