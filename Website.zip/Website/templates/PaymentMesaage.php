<?php
require_once '../layout/header.php'?>

	<h3>Payment Submit Successfully. We will send you more details as soon as possible </h3>
    <h4><a href="index.php"> <br> Click here to return to home page</a></h4>


<?php
	//session_destroy();

require_once '../layout/footer.php'
?>