<?php

namespace src;

use src\Booking;

class CancelBooking extends Booking
{

    public function __construct()
    {
        $this->bookingId;
    }
}