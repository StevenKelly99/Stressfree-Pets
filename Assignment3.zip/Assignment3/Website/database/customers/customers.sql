create schema customers;

