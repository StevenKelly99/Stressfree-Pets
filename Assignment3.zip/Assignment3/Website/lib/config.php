<?php
$configVars = array(
    'database_dsn' =>'mysql:dbname=streesfreepets; host=localhost',
    'database_user' => 'root',
    'database_pass' => '2Trinlight#',
);
return $configVars;