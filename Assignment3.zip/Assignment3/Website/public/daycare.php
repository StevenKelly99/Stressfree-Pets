<?php require_once "../layout/header.php";?>
<h1 class="headingFaq">Dog daycare</h1>

<div class="daycare">
    <div class="centre">
        <img src="../images/daycare.jpg" height="300" width="550" alt="petWalkingImg"></div>
    <p>Daycare is going to make your pet more socialised, play, and do exercise.
        To prevent loneliness and anxiety, watch your dog and take care of it.
        by specialised personnel</p>

    <p>if you think this service is perfect for you can
        <a href="booking.php"><button type="button">Book here</button></a></p>
</div>


<?php require_once "../layout/footer.php"; ?>
