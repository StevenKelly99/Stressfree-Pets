<?php
    require_once '../src/Sessions.php';
    $session = new \src\Sessions();
    $session ->forgetSession();
