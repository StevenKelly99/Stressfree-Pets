

<?php require_once '../layout/header.php'; ?>





<?php

echo "Thanks for submitting the form. You will be contacted once your application has been processed";

?>
<a href="index.php">Click here to return to home page</a>
<?php require_once'../layout/footer.php'; ?>