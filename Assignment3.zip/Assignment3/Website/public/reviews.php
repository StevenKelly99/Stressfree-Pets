<?php require_once '../layout/header.php'; ?>
<h1>Reviews</h1>

<?php require_once '../layout/footer.php'; ?>
