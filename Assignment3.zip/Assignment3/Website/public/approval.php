<?php require_once '../layout/header.php'; ?>
<div class ="container">
    <button type="button">Approve</button>
    <button type = "button">Deny</button>
</div>

<?php require_once '../layout/footer.php'; ?>