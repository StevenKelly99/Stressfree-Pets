<?php require_once"../layout/header.php"?>

<h1 class="headingFaq">Pet Walking</h1>
<div class="petWalking">
    <div class="centre">
        <img src="../images/petWalking.jpg" height="300" width="650" alt="petWalkingImg"></div>
    <p>Pet Walking Service is providing help for your pets, such as taking your dog to the vet.
        helping your dog lose weight, keeping track of your dog's food,
        Keep an eye on your pet's health. Help your dog learn new things.
        Clean your dog's stuff and give your dog a bath.</p>

    <p>if you think this service is perfect for you can
        <a href="booking.php"><button type="button">Book here</button></a></p>
</div>

<?php require_once"../layout/footer.php" ?>



